package ar.com.facturacion;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import com.lowagie.text.pdf.PdfReader;
import java.io.ByteArrayInputStream;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("demo")
class FacturaIntegrationTest {
 @Autowired MockMvc mvc;
 @Test void reporteProyectaClienteNuloYCuentaDetallesIncluyendoCero() throws Exception {
  mvc.perform(get("/api/facturas")).andExpect(status().isOk()).andExpect(jsonPath("$.length()").value(4))
   .andExpect(jsonPath("$[0].clienteDenominacion").value("Consumidor Final"))
   .andExpect(jsonPath("$[0].cantidadItems").value(2)).andExpect(jsonPath("$[1].cantidadItems").value(5))
   .andExpect(jsonPath("$[3].cantidadItems").value(0)).andExpect(jsonPath("$[0].fechaEmision").value("2026-03-15"));
 }
 @Test void combinaLosCuatroFiltros() throws Exception {
  mvc.perform(get("/api/facturas").param("fechaDesde","2026-03-01").param("fechaHasta","2026-03-31").param("estado","EMITIDA").param("montoMinimo","1500"))
   .andExpect(status().isOk()).andExpect(jsonPath("$.length()").value(2));
 }
 @Test void fechaHastaIncluyeUltimoMinutoDelDia() throws Exception {
  mvc.perform(get("/api/facturas").param("fechaDesde","2026-03-25").param("fechaHasta","2026-03-25"))
   .andExpect(status().isOk()).andExpect(jsonPath("$.length()").value(1)).andExpect(jsonPath("$[0].numeroFactura").value(1003));
 }
 @Test void filtraEstadoMontoYFechasPorSeparado() throws Exception {
  mvc.perform(get("/api/facturas").param("estado"," anulada ")).andExpect(status().isOk()).andExpect(jsonPath("$.length()").value(1));
  mvc.perform(get("/api/facturas").param("montoMinimo","85000.5")).andExpect(status().isOk()).andExpect(jsonPath("$.length()").value(1));
  mvc.perform(get("/api/facturas").param("fechaDesde","2026-04-01")).andExpect(status().isOk()).andExpect(jsonPath("$.length()").value(1));
  mvc.perform(get("/api/facturas").param("fechaHasta","2026-03-15")).andExpect(status().isOk()).andExpect(jsonPath("$.length()").value(1));
 }
 @Test void rechazaFiltrosInvalidos() throws Exception {
  mvc.perform(get("/api/facturas").param("fechaDesde","2026-04-01").param("fechaHasta","2026-03-01")).andExpect(status().isBadRequest());
  for (String n:new String[]{"-1","NaN","Infinity","hola"}) mvc.perform(get("/api/facturas").param("montoMinimo",n)).andExpect(status().isBadRequest());
  mvc.perform(get("/api/facturas").param("fechaDesde","no-es-fecha")).andExpect(status().isBadRequest());
 }
 @Test void exportaPdfYExcelDeLaMismaConsultaFiltrada() throws Exception {
  var pdf=mvc.perform(get("/api/facturas/reporte/pdf").param("estado","ANULADA")).andExpect(status().isOk()).andExpect(content().contentType("application/pdf")).andReturn().getResponse().getContentAsByteArray();
  var lector=new PdfReader(pdf); assertTrue(lector.getNumberOfPages()>0); lector.close();
  var excel=mvc.perform(get("/api/facturas/reporte/excel").param("estado","ANULADA")).andExpect(status().isOk()).andReturn().getResponse().getContentAsByteArray();
  try(var libro=new XSSFWorkbook(new ByteArrayInputStream(excel))) {
   var hoja=libro.getSheetAt(0); assertEquals(2,hoja.getLastRowNum()); assertEquals("1003",hoja.getRow(1).getCell(0).getStringCellValue());
   assertEquals(3000,hoja.getRow(2).getCell(5).getNumericCellValue(),.01);
  }
 }
 @Test void exportaReporteVacio() throws Exception {
  var bytes=mvc.perform(get("/api/facturas/reporte/excel").param("montoMinimo","999999")).andExpect(status().isOk()).andReturn().getResponse().getContentAsByteArray();
  try(var libro=new XSSFWorkbook(new ByteArrayInputStream(bytes))) { assertEquals(0,libro.getSheetAt(0).getRow(1).getCell(5).getNumericCellValue()); }
  mvc.perform(get("/api/facturas/reporte/pdf").param("montoMinimo","999999")).andExpect(status().isOk());
 }
 @Test void entidadTransitoriaNoSeConfundeConOtra() {
  var a=new ar.com.facturacion.modelo.FacturaVenta(); var b=new ar.com.facturacion.modelo.FacturaVenta();
  assertNotEquals(a,b); var d=new ar.com.facturacion.modelo.FacturaVentaDetalle(); a.agregarDetalle(d); assertSame(a,d.getFactura()); a.quitarDetalle(d); assertNull(d.getFactura());
 }
}

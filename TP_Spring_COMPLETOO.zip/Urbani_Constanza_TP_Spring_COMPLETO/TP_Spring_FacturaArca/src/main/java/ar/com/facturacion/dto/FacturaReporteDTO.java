package ar.com.facturacion.dto;
import lombok.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;
@Getter @Setter @AllArgsConstructor @NoArgsConstructor
public class FacturaReporteDTO {
 private Long numeroFactura;
 @JsonFormat(pattern = "yyyy-MM-dd", timezone = "America/Argentina/Mendoza")
 private Date fechaEmision;
 private String clienteDenominacion;
 private String condicionIva;
 private String puntoVentaDescripcion;
 private double importeTotal;
 private long cantidadItems;
}

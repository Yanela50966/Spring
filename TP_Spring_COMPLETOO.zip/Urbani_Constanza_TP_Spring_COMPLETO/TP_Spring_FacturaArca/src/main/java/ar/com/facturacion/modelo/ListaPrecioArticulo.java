package ar.com.facturacion.modelo;

import lombok.*;

import jakarta.persistence.*;

@Entity
@Table(name = "lista_precio_articulo")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true, onlyExplicitlyIncluded = true)
public class ListaPrecioArticulo extends AuditoriaApp {
    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "lista_precio_id", nullable = false)
    private ListaPrecio listaPrecio;

    @Column(nullable = false)
    private double precioVenta;

    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "articulo_id", nullable = false)
    private Articulo articulo;

}

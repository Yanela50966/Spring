package ar.com.facturacion.service;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ar.com.facturacion.dto.FacturaReporteDTO;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

@Service
@Transactional(readOnly = true)
public class FacturaService {
  @PersistenceContext
  private EntityManager em;
  private static final ZoneId ZONA = ZoneId.of("America/Argentina/Mendoza");

  public List<FacturaReporteDTO> buscarFacturasFiltradas(LocalDate desde, LocalDate hasta, String estado,
      Double minimo) {
    if (desde != null && hasta != null && desde.isAfter(hasta))
      throw new IllegalArgumentException("fechaDesde no puede superar fechaHasta");
    if (minimo != null && (!Double.isFinite(minimo) || minimo < 0))
      throw new IllegalArgumentException("montoMinimo debe ser un número finito mayor o igual a cero");
    StringBuilder jpql = new StringBuilder("""
        SELECT new ar.com.facturacion.dto.FacturaReporteDTO(
          f.numero, f.fechaEmision, COALESCE(c.denominacion, 'Consumidor Final'),
          ci.denominacion, pv.descripcion, f.importeTotal, COUNT(d))
        FROM FacturaVenta f
        LEFT JOIN f.cliente c
        JOIN f.condicionIva ci
        JOIN f.puntoVenta pv
        LEFT JOIN f.detalles d
        WHERE 1=1
        """);
    Map<String, Object> parametros = new HashMap<>();
    if (desde != null) {
      jpql.append(" AND f.fechaEmision >= :desde");
      parametros.put("desde", Date.from(desde.atStartOfDay(ZONA).toInstant()));
    }
    // Límite exclusivo del día siguiente: incluye todo el día fechaHasta.
    if (hasta != null) {
      jpql.append(" AND f.fechaEmision < :hasta");
      parametros.put("hasta", Date.from(hasta.plusDays(1).atStartOfDay(ZONA).toInstant()));
    }
    if (estado != null && !estado.isBlank()) {
      jpql.append(" AND f.estado = :estado");
      parametros.put("estado", estado.trim().toUpperCase(Locale.ROOT));
    }
    if (minimo != null) {
      jpql.append(" AND f.importeTotal >= :minimo");
      parametros.put("minimo", minimo);
    }
    jpql.append(
        " GROUP BY f.id, f.numero, f.fechaEmision, c.denominacion, ci.denominacion, pv.descripcion, f.importeTotal ORDER BY f.fechaEmision, f.numero, f.id");
    var query = em.createQuery(jpql.toString(), FacturaReporteDTO.class);
    parametros.forEach(query::setParameter);
    return query.getResultList();
  }
}

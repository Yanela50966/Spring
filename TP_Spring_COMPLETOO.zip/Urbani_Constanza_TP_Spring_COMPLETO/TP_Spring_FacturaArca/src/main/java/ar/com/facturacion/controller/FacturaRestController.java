package ar.com.facturacion.controller;
import ar.com.facturacion.dto.FacturaReporteDTO;
import ar.com.facturacion.service.*;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.util.List;
import java.io.IOException;
@RestController
@RequestMapping("/api/facturas")
@RequiredArgsConstructor
public class FacturaRestController {
 private final FacturaService facturas;
 private final ReporteService reportes;
 @GetMapping
 public List<FacturaReporteDTO> buscar(
   @RequestParam(required=false) @DateTimeFormat(iso=DateTimeFormat.ISO.DATE) LocalDate fechaDesde,
   @RequestParam(required=false) @DateTimeFormat(iso=DateTimeFormat.ISO.DATE) LocalDate fechaHasta,
   @RequestParam(required=false) String estado,
   @RequestParam(required=false) Double montoMinimo) {
  return facturas.buscarFacturasFiltradas(fechaDesde,fechaHasta,estado,montoMinimo);
 }
 @GetMapping("/reporte/pdf")
 public ResponseEntity<byte[]> pdf(
   @RequestParam(required=false) @DateTimeFormat(iso=DateTimeFormat.ISO.DATE) LocalDate fechaDesde,
   @RequestParam(required=false) @DateTimeFormat(iso=DateTimeFormat.ISO.DATE) LocalDate fechaHasta,
   @RequestParam(required=false) String estado,
   @RequestParam(required=false) Double montoMinimo) throws IOException {
  return descarga(reportes.pdf(buscar(fechaDesde,fechaHasta,estado,montoMinimo)), "application/pdf", "reporte_facturas.pdf");
 }
 @GetMapping("/reporte/excel")
 public ResponseEntity<byte[]> excel(
   @RequestParam(required=false) @DateTimeFormat(iso=DateTimeFormat.ISO.DATE) LocalDate fechaDesde,
   @RequestParam(required=false) @DateTimeFormat(iso=DateTimeFormat.ISO.DATE) LocalDate fechaHasta,
   @RequestParam(required=false) String estado,
   @RequestParam(required=false) Double montoMinimo) throws IOException {
  return descarga(reportes.excel(buscar(fechaDesde,fechaHasta,estado,montoMinimo)), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "reporte_facturas.xlsx");
 }
 private ResponseEntity<byte[]> descarga(byte[] datos, String tipo, String nombre) {
  return ResponseEntity.ok().contentType(MediaType.parseMediaType(tipo)).header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\""+nombre+"\"").body(datos);
 }
}

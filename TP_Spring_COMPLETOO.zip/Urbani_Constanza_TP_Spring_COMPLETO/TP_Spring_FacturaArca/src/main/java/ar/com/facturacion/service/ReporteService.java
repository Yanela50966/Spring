package ar.com.facturacion.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.TimeZone;

import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import com.lowagie.text.Document;
import com.lowagie.text.FontFactory;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

import ar.com.facturacion.dto.FacturaReporteDTO;

@Service
public class ReporteService {
    private static final String[] TITULOS = { "Factura", "Fecha", "Cliente", "Condición IVA", "Punto de venta",
            "Importe total", "Ítems" };

    private SimpleDateFormat formatoFecha() {
        var f = new SimpleDateFormat("yyyy-MM-dd");
        f.setTimeZone(TimeZone.getTimeZone("America/Argentina/Mendoza"));
        return f;
    }

    public byte[] pdf(java.util.List<FacturaReporteDTO> facturas) throws IOException {
        var salida = new ByteArrayOutputStream();
        var documento = new Document(PageSize.A4.rotate(), 24, 24, 24, 24);
        PdfWriter.getInstance(documento, salida);
        documento.open();
        documento
                .add(new Paragraph("Reporte ejecutivo de ventas", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 16)));
        documento.add(new Paragraph("Facturas encontradas: " + facturas.size()));
        documento.add(new Paragraph(" "));
        var tabla = new PdfPTable(7);
        tabla.setWidthPercentage(100);
        tabla.setWidths(new float[] { 1, 1.5f, 2.5f, 2.5f, 2, 1.7f, .7f });
        tabla.setHeaderRows(1);
        for (String t : TITULOS) {
            var celda = new PdfPCell(new Phrase(t, FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10)));
            celda.setBackgroundColor(new java.awt.Color(220, 230, 240));
            celda.setPadding(6);
            tabla.addCell(celda);
        }
        double total = 0;
        for (var f : facturas) {
            String[] valores = { String.valueOf(f.getNumeroFactura()), formatoFecha().format(f.getFechaEmision()),
                    f.getClienteDenominacion(), f.getCondicionIva(), f.getPuntoVentaDescripcion(),
                    String.format(Locale.forLanguageTag("es-AR"), "%.2f", f.getImporteTotal()),
                    String.valueOf(f.getCantidadItems()) };
            for (String v : valores) {
                var celda = new PdfPCell(new Phrase(v == null ? "" : v, FontFactory.getFont(FontFactory.HELVETICA, 9)));
                celda.setPadding(5);
                tabla.addCell(celda);
            }
            total += f.getImporteTotal();
        }
        documento.add(tabla);
        documento.add(
                new Paragraph(String.format(Locale.forLanguageTag("es-AR"), "Total de las facturas: $ %,.2f", total)));
        documento.close();
        return salida.toByteArray();
    }

    public byte[] excel(java.util.List<FacturaReporteDTO> facturas) throws IOException {
        try (var libro = new XSSFWorkbook(); var salida = new ByteArrayOutputStream()) {
            var hoja = libro.createSheet("Reporte ventas");
            var cabecera = libro.createCellStyle();
            var fuente = libro.createFont();
            fuente.setBold(true);
            cabecera.setFont(fuente);
            cabecera.setFillForegroundColor(IndexedColors.LIGHT_CORNFLOWER_BLUE.getIndex());
            cabecera.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            var fecha = libro.createCellStyle();
            fecha.setDataFormat(libro.createDataFormat().getFormat("yyyy-mm-dd"));
            var moneda = libro.createCellStyle();
            moneda.setDataFormat(libro.createDataFormat().getFormat("#,##0.00"));
            var encabezado = hoja.createRow(0);
            for (int i = 0; i < TITULOS.length; i++) {
                var c = encabezado.createCell(i);
                c.setCellValue(TITULOS[i]);
                c.setCellStyle(cabecera);
            }
            int numero = 1;
            for (var f : facturas) {
                var fila = hoja.createRow(numero++);
                // Texto para conservar números Long grandes sin pérdida de precisión en Excel.
                fila.createCell(0).setCellValue(String.valueOf(f.getNumeroFactura()));
                fila.createCell(1).setCellValue(f.getFechaEmision().toInstant()
                        .atZone(java.time.ZoneId.of("America/Argentina/Mendoza")).toLocalDate().atStartOfDay());
                fila.getCell(1).setCellStyle(fecha);
                fila.createCell(2).setCellValue(f.getClienteDenominacion());
                fila.createCell(3).setCellValue(f.getCondicionIva());
                fila.createCell(4).setCellValue(f.getPuntoVentaDescripcion());
                fila.createCell(5).setCellValue(f.getImporteTotal());
                fila.getCell(5).setCellStyle(moneda);
                fila.createCell(6).setCellValue(f.getCantidadItems());
            }
            var total = hoja.createRow(numero);
            total.createCell(4).setCellValue("TOTAL");
            var importe = total.createCell(5);
            if (numero > 1)
                importe.setCellFormula("SUM(F2:F" + numero + ")");
            else
                importe.setCellValue(0);
            importe.setCellStyle(moneda);
            libro.getCreationHelper().createFormulaEvaluator().evaluateAll();
            hoja.createFreezePane(0, 1);
            hoja.setAutoFilter(new org.apache.poi.ss.util.CellRangeAddress(0, Math.max(0, numero - 1), 0, 6));
            for (int i = 0; i < 7; i++) {
                hoja.autoSizeColumn(i);
                hoja.setColumnWidth(i, Math.min(16000, hoja.getColumnWidth(i) + 700));
            }
            libro.write(salida);
            return salida.toByteArray();
        }
    }
}

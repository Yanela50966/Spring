package ar.com.facturacion.modelo;

import lombok.*;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.MappedSuperclass;

@MappedSuperclass
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public abstract class EntityId {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    protected Long id;

// Dos entidades transitorias diferentes no se consideran iguales.
    @Override
    public boolean equals(Object otro) {
        if (this == otro) return true;
        if (otro == null || org.hibernate.Hibernate.getClass(this) != org.hibernate.Hibernate.getClass(otro)) return false;
        return id != null && id.equals(((EntityId) otro).getId());
    }
    @Override
    public int hashCode() { return org.hibernate.Hibernate.getClass(this).hashCode(); }
}

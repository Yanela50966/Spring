package ar.com.facturacion.controller;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
@RestControllerAdvice
public class ApiExceptionHandler {
 @ExceptionHandler(IllegalArgumentException.class)
 public ProblemDetail argumento(IllegalArgumentException ex) { return ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, ex.getMessage()); }
 @ExceptionHandler(MethodArgumentTypeMismatchException.class)
 public ProblemDetail formato(MethodArgumentTypeMismatchException ex) { return ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, "Formato inválido en " + ex.getName() + ". Fechas: yyyy-MM-dd. Monto: número con punto decimal."); }
}

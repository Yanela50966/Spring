package ar.com.facturacion.modelo;

import lombok.*;

import jakarta.persistence.*;

@Entity
@Table(name = "articulo")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true, onlyExplicitlyIncluded = true)
public class Articulo extends AuditoriaApp {
    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "rubro_id")
    private Rubro rubro;

    @Column(nullable = false)
    private String codigo;

    @Column(nullable = false)
    private String denominacion;

    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "marca_id")
    private Marca marca;

}

package ar.com.facturacion.config;
import ar.com.facturacion.modelo.*;
import jakarta.persistence.*;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import java.time.*;
import java.util.Date;
@Component
@ConditionalOnProperty(name="app.demo.enabled", havingValue="true")
@RequiredArgsConstructor
public class DatosDemo implements CommandLineRunner {
 @PersistenceContext private EntityManager em;
 @Override @Transactional
 public void run(String... args) {
  if (em.createQuery("SELECT COUNT(f) FROM FacturaVenta f",Long.class).getSingleResult()>0) return;
  var u = new Usuario("demo","NO_ES_UN_LOGIN","Constanza","Urbani"); em.persist(u);
  var pv=new PuntoVenta(); pv.setNumero(1); pv.setDescripcion("Sucursal Central"); auditar(pv,u); em.persist(pv);
  var iva=new CondicionIva(); iva.setCodigoAfip(1); iva.setDenominacion("IVA Responsable Inscripto"); auditar(iva,u); em.persist(iva);
  var moneda=new TipoMoneda(); moneda.setCodigoAfip("PES"); moneda.setDenominacion("Peso argentino"); moneda.setSimbolo("$"); auditar(moneda,u); em.persist(moneda);
  var cliente=new Cliente(); cliente.setCuitCuil("30-00000000-0"); cliente.setDenominacion("Empresa Tech S.A."); cliente.setContacto(new Contacto("demo@example.com","","")); cliente.setDomicilio(new Domicilio("San Martín","100")); auditar(cliente,u); em.persist(cliente);
  var articulo=new Articulo(); articulo.setCodigo("ART-DEMO"); articulo.setDenominacion("Producto de prueba"); auditar(articulo,u); em.persist(articulo);
  var lista=new ListaPrecio(); lista.setCodigo("LP-DEMO"); lista.setDenominacion("Lista general"); auditar(lista,u); em.persist(lista);
  var precio=new ListaPrecioArticulo(); precio.setArticulo(articulo); precio.setListaPrecio(lista); precio.setPrecioVenta(1000); auditar(precio,u); em.persist(precio);
  crear(1001L,"2026-03-15T10:00:00","EMITIDA",1500,2,null,pv,iva,moneda,precio,u);
  crear(1002L,"2026-03-20T12:00:00","EMITIDA",85000.5,5,cliente,pv,iva,moneda,precio,u);
  crear(1003L,"2026-03-25T23:59:00","ANULADA",3000,1,cliente,pv,iva,moneda,precio,u);
  crear(1004L,"2026-04-01T09:00:00","EMITIDA",0,0,null,pv,iva,moneda,precio,u);
 }
 private void crear(Long numero,String fecha,String estado,double total,int items,Cliente cliente,PuntoVenta pv,CondicionIva iva,TipoMoneda moneda,ListaPrecioArticulo precio,Usuario u) {
  var f=new FacturaVenta(); f.setNumero(numero); f.setFechaEmision(Date.from(LocalDateTime.parse(fecha).atZone(ZoneId.of("America/Argentina/Mendoza")).toInstant()));
  f.setCliente(cliente); f.setPuntoVenta(pv); f.setCondicionIva(iva); f.setTipoMoneda(moneda); f.setEstado(estado); f.setImporteTotal(total); f.setImporteSaldo(total); auditar(f,u);
  if (estado.equals("ANULADA")) f.setFechaAnulacion(f.getFechaEmision());
  double acumulado=0;
  for(int i=0;i<items;i++) { var d=new FacturaVentaDetalle(); d.setListaPrecioArticulo(precio); d.setDescripcion("Ítem "+(i+1)); d.setCantidad(1); double sub=i==items-1?total-acumulado:Math.round(total/items*100)/100.0; acumulado+=sub; d.setPrecioUnitario(sub); d.setImporteNeto(sub); d.setImporteSubtotal(sub); f.agregarDetalle(d); }
  em.persist(f);
 }
 private void auditar(AuditoriaApp entidad,Usuario usuario) { Date ahora=new Date(); entidad.setFechaAlta(ahora); entidad.setFechaModificacion(ahora); entidad.setUsuarioCarga(usuario); entidad.setUsuarioModificacion(usuario); }
}

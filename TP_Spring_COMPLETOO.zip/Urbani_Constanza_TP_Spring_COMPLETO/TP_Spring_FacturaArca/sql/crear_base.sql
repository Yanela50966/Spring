CREATE DATABASE IF NOT EXISTS facturacion_spring CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
